#' Save a Model
#'
#' Takes in a model as string and stores it in object storage along with the model meta
#' in meta store
#'
#' @param content String content of the model
#' @param modelName Name of the model
#' @param description Description of the model
#' @param baseModelId If specified, current model will be created as version of the model specified by baseModelId
#' @param trainingDataPath Specifies training data path location used for generating the model
#' @param trainingSchema Schema of the data used for model training
#'
#' @return ID and version of the saved model
#' @export
model.save <- function(content,
                      modelName,
                      description,
                      baseModelId = NULL,
                      trainingDataPath = NULL,
                      trainingSchema = NULL) {
    library(httr)
    library(base64enc)
    library(jsonlite)
    library(yaml)
    library(rJava)
    .jinit()
    .jaddClassPath("/java-swift-library.jar")

    all_env <- yaml.load_file('/config.yaml')
    projectId <- all_env$PROJECT_ID
    encrypted_token <- all_env$PROJECT_TOKEN

    ek <- file("/etc/secret/tokenkey/projectdecryptionkey", "r")
    d_key <- readLines(ek, n = 1, warn = FALSE)
    close(ek)
    token = decryptPasswordImpl(encrypted_token, d_key)

    user_env <- yaml.load_file('/user.conf')
    userId <- user_env$USER_ID

    url <- paste("https://model-service.default:31400/v1/models?projectId=", projectId,
    "&scope=project&scopeId=", projectId, "&token=", token, sep="")

    serd <- serialize(content, NULL)

    sizeMB <- as.integer(ceiling(object.size(content) / 1024 / 1024))

    body <- list(content = base64encode(serd),
                 modelName = modelName,
                 runtime = "R",
                 baseModelId = baseModelId,
                 description = description,
                 trainingDataPath = trainingDataPath,
                 trainingSchema = trainingSchema,
                 sizeMB = sizeMB,
                 userId = userId)

    set_config(config(ssl_verifypeer = 0L))
    r <- PUT(url, add_headers("Expect" = ""), body = body, encode = "json")

    json <- content(r, "text")
    code <- status_code(r)

    response <- fromJSON(json)

    if (code != 201) {
        stop(prettify(json, indent = 4))
    }

    ret <- list(modelId = response$modelId, modelVersionId = response$modelVersionId, version = response$version)

    return (ret)
}

#' Load a saved Model
#'
#' Takes in a model as string and stores it in object storage along with the model meta
#' in meta store
#'
#' @param modelId Model ID of the model to load
#' @param modelVersionId Model version ID or version of the model to load, if ignored latest version will be loaded
#'
#' @return Content of the model
#' @export
model.load <- function(modelId, modelVersion = NULL) {
    library(httr)
    library(base64enc)
    library(yaml)
    library(jsonlite)
    library(rJava)
    .jinit()
    .jaddClassPath("/java-swift-library.jar")

    all_env <- yaml.load_file('/config.yaml')
    projectId <- all_env$PROJECT_ID
    encrypted_token <- all_env$PROJECT_TOKEN

    ek <- file("/etc/secret/tokenkey/projectdecryptionkey", "r")
    d_key <- readLines(ek, n = 1, warn = FALSE)
    close(ek)
    token = decryptPasswordImpl(encrypted_token, d_key)

    user_env <- yaml.load_file('/user.conf')
    userId <- user_env$USER_ID

    url <- paste("https://model-service.default:31400/v1/models/", modelId, sep="")

    if (!is.null(modelVersion)) {
        url <- paste(url, "/versions/", modelVersion, sep="")
    }

    url <- paste(url, "?projectId=", projectId, "&scope=project&scopeId=", projectId, "&token=",
    token, "&userId=", userId, sep="")

    set_config(config(ssl_verifypeer = 0L))
    r <- GET(url)

    json <- content(r, "text")
    response <- fromJSON(json)
    code <- status_code(r)

    if (code != 200) {
        stop(prettify(json, indent = 4))
    }

    return (unserialize(base64decode(response$content)))
}

decryptPasswordImpl <- function(passwd, secretKey) {
    obj <- .jnew("com.walmart.analytics.platform.datasets.encryption.EncryptionUtil")
    p <- .jcall(obj, "Ljava/lang/String;", "decryptData", passwd, secretKey)
    return(p)
}